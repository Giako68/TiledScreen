/********************************************************************************
 * TiledScreen  
 *******************************************************************************/

#include <TiledScreen.h>

extern void enableFpgaClock(void);

#define no_data         0xFF, 0xFF, 0xFF, 0xFF, \
                        0xFF, 0xFF, 0xFF, 0xFF, \
                        0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, 0xFF, \
                        0xFF, 0xFF, 0xFF, 0xFF, \
                        0x00, 0x00, 0x00, 0x00  \

#define NO_BOOTLOADER   no_data
#define NO_APP          no_data
#define NO_USER_DATA    no_data

__attribute__ ((used, section(".fpga_bitstream_signature")))
const unsigned char signatures[4096] = {
#include <utils/signature.h>
};
__attribute__ ((used, section(".fpga_bitstream")))
const unsigned char bitstream[] = {
#include <utils/app.h>
};

/*
 *       PRIVATE FUNCTIONS
 */

static void FPGA_ActivateAppImage()
{ static uint8_t data[9] = {0x03, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00};
  enableFpgaClock();
  jtag_host_setup();
  JTAG_Write_VDR_to_VIR(0x00, data, 66);
  pinMode(31, OUTPUT);
  digitalWrite(31, LOW);
  data[4] = 0x03;
  JTAG_Write_VDR_to_VIR(0x00, data, 66);
  digitalWrite(31, HIGH);
  digitalWrite(31, LOW);
  delay(1000);
}

TiledScreen* TiledScreen::SingleInstance = NULL;

TiledScreen::TiledScreen()
{ FPGA_ActivateAppImage();
  Width = 40;
  Height = 23;
  XView = 0;
  YView = 0;
  BaseAddress = 0x000000;
  TilesAddress = 0x010000;
  CTRL = 0x00;
  setCTRL();
  setGeometry();
}

void TiledScreen::setCTRL()
{ JTAG_Write_VDR_to_VIR(0x01, &CTRL, 3);
}

uint16_t TiledScreen::ReadWriteSDRAM(uint32_t address, uint16_t data, uint8_t mask)   // address is 22 bits: 4 Mega * 16 bit Words
{ uint8_t vdr[5];
  uint8_t ret[3];
  vdr[0] = (uint8_t)(data & 0xFF);
  vdr[1] = (uint8_t)((data >> 8) & 0xFF);
  vdr[2] = (uint8_t)(((address << 2) & 0xFC) | (mask & 0x03));
  vdr[3] = (uint8_t)((address >> 6) & 0xFF);
  vdr[4] = (uint8_t)((address >> 14) & 0xFF);
  JTAG_Write_VDR_to_VIR(0x02, vdr, 40);
  if (mask == 0x03)
     { JTAG_Read_VDR_from_VIR(0x0F, ret, 40);
       do { JTAG_Read_VDR_from_VIR(0x03, ret, 17);
          } while(ret[2] != 0x01);
       return((((uint16_t)ret[1]) << 8) | ret[0]);
     }
  return(0x0000);
}

void TiledScreen::setGeometry()
{ uint8_t vdr[7];
  uint32_t StartAddress = BaseAddress + (YView >> 4) * Width + (XView >> 4);
  uint16_t Delta = Width - 40;
  uint8_t  Xoff = XView & 0x000F;
  uint8_t  Yoff = YView & 0x000F;
  vdr[0] = StartAddress & 0xFF;
  vdr[1] = (StartAddress >> 8) & 0xFF;
  vdr[2] = ((StartAddress >> 16) & 0x7F) | ((Delta << 7) & 0x80);
  vdr[3] = (Delta >> 1) & 0xFF;
  vdr[4] = ((Delta >> 9) & 0x7F) | ((TilesAddress >> 9) & 0x80);
  vdr[5] = ((TilesAddress >> 17) & 0x3F) | ((Xoff << 6) & 0xC0);
  vdr[6] = ((Xoff >> 2) & 0x03) | ((Yoff << 2) & 0x3C);
  JTAG_Write_VDR_to_VIR(0x06, vdr, 54);
}

/*
 *       PUBLIC FUNCTIONS
 */

TiledScreen* TiledScreen::getInstance()
{ if (SingleInstance == NULL) SingleInstance = new TiledScreen();
  return(SingleInstance);
}

void TiledScreen::setReset(bool value)
{ if (value) CTRL = CTRL & 0xFB;
  else CTRL = CTRL | 0x04;
  setCTRL();
}

void TiledScreen::setBlank(bool value)
{ if (value) CTRL = CTRL | 0x01;
  else CTRL = CTRL & 0xFE;
  setCTRL();
}

void TiledScreen::setBlankColor(uint8_t R, uint8_t G, uint8_t B)
{ uint8_t data[3];
  data[0] = B;
  data[1] = G;
  data[2] = R;
  JTAG_Write_VDR_to_VIR(0x07, data, 24);
}

void TiledScreen::writeByte(uint32_t address, uint8_t value)    // address is 23 bits long, 8MB SDRAM.
{ uint16_t data;
  uint8_t mask;
  if ((address & 0x00000001) == 0)
     { data = ((uint16_t)value) << 8;
       mask = 0x01;
     }
  else { data = (uint16_t)value;
         mask = 0x02;
       }
  ReadWriteSDRAM((address >> 1), data, mask);
}
  
uint8_t TiledScreen::readByte(uint32_t address)                 // address is 23 bits long, 8MB SDRAM.
{ uint16_t data;
  data = ReadWriteSDRAM((address >> 1), 0x0000, 0x03);
  if ((address & 0x00000001) == 0) return((uint8_t)(data >> 8));
  return((uint8_t)(data & 0x00FF));
}

void TiledScreen::writeWord(uint32_t address, uint16_t value)   // address is 23 bits long, but only even addresses are allowed, so the least significant bit is ignored.
{ ReadWriteSDRAM((address >> 1), value, 0x00);
}

uint16_t TiledScreen::readWord(uint32_t address)                // address is 23 bits long, but only even addresses are allowed, so the least significant bit is ignored.
{ return(ReadWriteSDRAM((address >> 1), 0x0000, 0x03));
}

void TiledScreen::fastWrite(uint32_t address, uint16_t *data, uint32_t num)  // address is 23 bits long, but only even addresses are allowed, so the least significant bit is ignored.
{ uint8_t vdr[3];
  vdr[0] = (address >> 1) & 0xFF;
  vdr[1] = (address >> 9) & 0xFF;
  vdr[2] = (address >> 17) & 0xFF;
  JTAG_Write_VDR_to_VIR(0x04, vdr, 22);
  JTAG_Write_VDR_to_VIR(0x05, (uint8_t *)data, num*16);
}

void TiledScreen::setAddress(uint32_t address)
{ BaseAddress = address & 0x007FFFFF;
  setGeometry();
}

void TiledScreen::setDimension(uint32_t width, uint32_t height)
{ Width = (width < 40) ? 40 : width;
  Height = (height < 23) ? 23 : height;
  setGeometry();
}

void TiledScreen::setView(uint32_t x, uint32_t y)
{ XView = (x > ((Width - 40) * 16)) ? ((Width - 40) * 16) : x;
  YView = (y > ((Height * 2 - 45) * 8)) ? ((Height * 2 - 45) * 8) : y;
  setGeometry();
}

void TiledScreen::setTileMap(uint32_t address)
{ TilesAddress = address & 0x007FFFFF;
  setGeometry();
}

void TiledScreen::setColor(uint8_t index, uint8_t R, uint8_t G, uint8_t B)
{ uint8_t vdr[5];
  vdr[0] = B;
  vdr[1] = G;
  vdr[2] = R;
  vdr[3] = index;
  vdr[4] = 0xFF;
  JTAG_Write_VDR_to_VIR(0x08, vdr, 33);
  vdr[4] = 0x00;
  JTAG_Write_VDR_to_VIR(0x08, vdr, 33);
}
