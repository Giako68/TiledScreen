/********************************************************************************
 * TiledScreen  
 *******************************************************************************/

#ifndef TILED_SCREEN_H
#define TILED_SCREEN_H

#include <Arduino.h>
#include <utils/JTAG.h>

class TiledScreen
{ public:
  static TiledScreen* getInstance(void);
  void                setReset(bool value);
  void                setBlank(bool value);
  void                setBlankColor(uint8_t R, uint8_t G, uint8_t B);
  void                writeByte(uint32_t address, uint8_t value);
  uint8_t             readByte(uint32_t address);
  void                writeWord(uint32_t address, uint16_t value);
  uint16_t            readWord(uint32_t address);
  void                fastWrite(uint32_t address, uint16_t *data, uint32_t num);
  void                setAddress(uint32_t address);
  void                setDimension(uint32_t width, uint32_t height);
  void                setView(uint32_t x, uint32_t y);
  void                setTileMap(uint32_t address);
  void                setColor(uint8_t index, uint8_t R, uint8_t G, uint8_t B);

  private:
  static TiledScreen* SingleInstance;
  uint32_t            Width;
  uint32_t            Height;
  uint32_t            XView;
  uint32_t            YView;
  uint32_t            BaseAddress;
  uint32_t            TilesAddress;
  uint8_t             CTRL;
  
                      TiledScreen(void);
                      TiledScreen(const TiledScreen&);
  TiledScreen&        operator=(const TiledScreen&);  
  void                setCTRL();
  uint16_t            ReadWriteSDRAM(uint32_t address, uint16_t data, uint8_t mask);
  void                setGeometry(void);
};

#endif
